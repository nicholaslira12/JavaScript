var valorTextDolar = prompt("Qual o valor em dolar que você quer converter?")

var valorNumDolar = parseFloat(valorTextDolar)

//alert(valorNumDolar)

var valorEmReal = valorNumDolar * 5.50
var valorEmRealLimitado = valorEmReal.toFixed(2)

alert(valorEmRealLimitado)

//Comandos
//variáveis var,float,int, string
//função alert, parseInt, parseFloat, prompt
//operações somar +, multiplicação *