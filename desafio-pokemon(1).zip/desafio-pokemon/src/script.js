var nomeDoPokemon = prompt("Digite 1 para Blastoize, 2 para Charizard, 3 para Venusaur: ")
var nomeDaEvolucao1 = ("A evolução é: Squirtle e Wartotle")
var nomeDaEvolucao2 = ("A evolução é: Charmander e Charmelion")
var nomeDaEvolucao3 = ("A evolução é: Ivisaur e Bubasaur")

if (nomeDoPokemon == 1) {
  var resposta = ("Blastoize")
  alert (resposta)
    if (resposta == "Blastoize"){
     alert (nomeDaEvolucao1)
      }  
}else if(nomeDoPokemon == 2) {
  var resposta = ("Charizard")
  alert (resposta)
  if (resposta == "Charizard"){
     alert (nomeDaEvolucao2)
  }   
}else if(nomeDoPokemon == 3) {
  var resposta = ("Venusaur")
  alert (resposta)
  if (resposta == "Venusaur"){
     alert (nomeDaEvolucao3)
  }
}
  else{
    alert("Opção Inválida")
    }